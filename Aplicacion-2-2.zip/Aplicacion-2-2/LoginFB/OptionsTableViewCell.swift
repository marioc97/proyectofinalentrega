//
//  OptionsTableViewCell.swift
//  LoginFB
//
//  Created by Cristian Lopez on 20/11/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class OptionsTableViewCell: UITableViewCell {

    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var ImagenMateria: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()

    }


}
