//
//  SecondQuestionViewController.swift
//  LoginFB
//
//  Created by Cristian Lopez on 06/12/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase


class SecondQuestionViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var table1: UITableView!
    @IBOutlet weak var table2: UITableView!
    @IBOutlet weak var P1: UITextView!
    @IBOutlet weak var P2: UITextView!
    
    @IBAction func boton(_ sender: UIButton) {
        print(Respuestas)
        print(Preguntas)
        a = Respuestas
        b = Respuestas
        table1.reloadData()
        table2.reloadData()
        print(Respuestas)
    }
    @IBAction func boton2(_ sender: UIButton) {
        Preguntas1 = Preguntas
        P1.text = Preguntas1[0]
        P2.text = Preguntas1[1]
    }
    var a = [["","","",""], ["","","",""]]
    var b = [["","","",""], ["","","",""]]
    var  vieneDeVistaUno: String = ""
    var Preguntas1 = ["",""]
    var Respuestas = [[String]]()
    var res = [String]()
    var Preguntas = [String]()
    var correcta = ""
    var correcta1 = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Res", Respuestas)
        print("Pre", Preguntas)
        P1.text = Preguntas1[0]
        P2.text = Preguntas1[1]
        
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == table1,
            let cell = tableView.dequeueReusableCell(withIdentifier: "CustomOne") as? QfTableViewCell {
            cell.F1.text = a[0][(indexPath.row)]
            return cell
        } else if tableView == table2,
            let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTwo") as? QsTableViewCell {
            cell.F2.text = a[1][(indexPath.row)]
            return cell
        }
        
        return UITableViewCell()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "tercera"{
            let destino = segue.destination as! FourthViewController
            destino.Preguntas = self.Preguntas
            let destino1 = segue.destination as! FourthViewController
            destino1.Respuestas = self.Respuestas
            print(destino.Preguntas)
            print(destino1.Respuestas)

        }
            
    }
    

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

/*
 docRef.getDocument { (document, error) in
 if let document = document, document.exists {
 let dataDescription = document.data().map(String.init(describing:)) ?? "nil"
 guard let dictionary = document.data() as? [String: Any] else {return}
 guard let dictionaryArray = dictionary["preguntas"] as? [[String: Any]] else {return}
 for i in 0...4{
 self.res.append(dictionaryArray[i]["a"]! as! String)
 self.res.append(dictionaryArray[i]["b"]! as! String)
 self.res.append(dictionaryArray[i]["c"]! as! String)
 self.res.append(dictionaryArray[i]["d"]! as! String)
 self.Respuestas.append(self.res)
 self.res.removeAll()
 }
 print(self.Respuestas)
 for j in 0...4{
 self.Preguntas.append(dictionaryArray[0]["reactivo "]! as! String)
 }
 print(self.Preguntas)
 
 }
 }
 */

