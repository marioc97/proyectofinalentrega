//
//  QfTableViewCell.swift
//  LoginFB
//
//  Created by Cristian Lopez on 06/12/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class QfTableViewCell: UITableViewCell {

    @IBOutlet weak var F1: UILabel!
    var viene: String = ""
    override func awakeFromNib() {
        super.awakeFromNib()
        F1.text = viene
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
