//
//  FirstTableViewCell.swift
//  LoginFB
//
//  Created by Cristian Lopez on 06/12/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class FirstTableViewCell: UITableViewCell {


    @IBOutlet weak var First: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
