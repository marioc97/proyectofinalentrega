//
//  FourthViewController.swift
//  LoginFB
//
//  Created by Cristian Lopez on 06/12/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBAction func boton1(_ sender: UIButton) {
        P3.text = Preguntas[2]
        P4.text = Preguntas[3]
    }
    
    @IBAction func boton2(_ sender: UIButton) {
        a = Respuestas
        b = Respuestas
        table4.reloadData()
        table3.reloadData()

    }
    @IBAction func boton3(_ sender: UIButton) {
    }
    @IBOutlet weak var table3: UITableView!
    @IBOutlet weak var table4: UITableView!
    @IBOutlet weak var P3: UITextView!
    @IBOutlet weak var P4: UITextView!
    var a = [["1","2","3","4"], ["7","8","9","10"], ["","","",""], ["","","",""]]
    var b = [["5","6","7","8"], ["","","",""], ["","","",""], ["","","",""]]
    var Preguntas = [String]()
    var Respuestas = [[String]]()
    override func viewDidLoad() {
        super.viewDidLoad()
        P3.text = ""
        P4.text = ""
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == table3,
            let cell = tableView.dequeueReusableCell(withIdentifier: "CustomThree") as? FourthTableViewCell {
            cell.P3.text = a[2][(indexPath.row)]
            return cell
        } else if tableView == table4,
            let cell = tableView.dequeueReusableCell(withIdentifier: "CustomFourth") as? FifthTableViewCell {
            cell.P4.text = a[2][(indexPath.row)]
            return cell
        }
        
        return UITableViewCell()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
