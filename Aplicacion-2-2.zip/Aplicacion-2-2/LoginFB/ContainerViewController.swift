//
//  ContainerViewController.swift
//  LoginFB
//
//  Created by Cristian Lopez on 04/12/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase

class ContainerViewController: UIViewController, UIPageViewControllerDataSource {
    var vieneDeVistaUno: String = ""
    var fisicaPregunta = ["Pregunta x","2"]
    var fisicaRespuestas = [["1","2","3","4","5"], ["1","2","3","4","5"]]
    var respuestasDeOptions = [[String]]()
    var preguntasDeOptions = [String]()
    var Preguntas = ["1","2","3","4","5"]
    var Preguntas1 = [String]()
    var Respuestas1 = [String]()
    var Respuestas2 = [["Respuesta 1", "Respuesta 2", "Respuesta 3", "Respuesta 4"],["Respuesta 5", "Respuesta 6 ", "Respuesta 7", "Respuesta 8"]]
    var Respuestas = [["Respuesta 1", "Respuesta 2", "Respuesta 3", "Respuesta 4"],["Respuesta 5", "Respuesta 6 ", "Respuesta 7", "Respuesta 8"]]
    var ref: DatabaseReference!
    override func viewDidLoad() {
        super.viewDidLoad()
        let pageController = self.storyboard?.instantiateViewController(withIdentifier: "pageViewController") as! UIPageViewController
        let startingViewController = viewCotrollerAtIndex(index: 0)!
        
        pageController.dataSource = self
        let viewControllers = [startingViewController]
        pageController.setViewControllers(viewControllers, direction: .forward, animated: true, completion: nil)
        pageController.view.frame = view.bounds
        self.addChild(pageController)
        self.view.addSubview(pageController.view)
        pageController.didMove(toParent: self)
        ref = Database.database().reference()
        let db = Firestore.firestore()
        let docRef = db.collection("Materias").document(vieneDeVistaUno)
        
        docRef.getDocument { (document, error) in
            if let document = document, document.exists {
                let dataDescription = document.data().map(String.init(describing:)) ?? "nil"
                guard let dictionary = document.data() as? [String: Any] else {return}
                guard let dictionaryArray = dictionary["preguntas"] as? [[String: Any]] else {return}
                //let answer = dictionaryArray.first!["a"]
                self.Respuestas2.removeAll()
                for i in 0...4{
                    self.Respuestas1.append(dictionaryArray[i]["a"]! as! String)
                    self.Respuestas1.append(dictionaryArray[i]["b"]! as! String)
                    self.Respuestas1.append(dictionaryArray[i]["c"]! as! String)
                    self.Respuestas1.append(dictionaryArray[i]["d"]! as! String)
                    self.Respuestas2.append(self.Respuestas1)
                    self.Respuestas1.removeAll()
                }
                print(self.Respuestas2)
                print(self.preguntasDeOptions)
                
            } else {
                print("Document does not exist")
            }
        }
        
    }

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        let viewController = viewController as! ContenentViewController
        var index = viewController.pagesIndex
        if index == 0 {
            return nil
        }
     
        return viewCotrollerAtIndex(index: index)
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        let viewController = viewController as! ContenentViewController
        var index = viewController.pagesIndex
        index = index + 1
        print(index)
        if index == fisicaPregunta.count{
            return nil
        }
        return viewCotrollerAtIndex(index: index)
    }
    


    
    func viewCotrollerAtIndex(index: Int)-> ContenentViewController?{

        
        if index >= fisicaPregunta.count {
            return nil
        }
        var contentViewController = self.storyboard?.instantiateViewController(withIdentifier: "contenentViewController") as! ContenentViewController

        contentViewController.text = fisicaPregunta[index]
        contentViewController.abs = fisicaRespuestas[index]

        if index == fisicaPregunta.count{
            
        }
        
        return contentViewController
    }
    



}


/*
 
 if preguntasDeOptions.count == 0 {
 contentViewController.text = fisicaPregunta[0]
 contentViewController.abs = fisicaRespuestas[0]
 }
 else{
 a=index
 contentViewController.text = preguntasDeOptions[a-1]
 contentViewController.abs = respuestasDeOptions[a-1]
 
 }
 
 */
